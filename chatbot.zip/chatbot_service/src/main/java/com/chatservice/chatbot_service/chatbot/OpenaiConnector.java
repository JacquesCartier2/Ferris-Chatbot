package com.chatservice.chatbot_service.chatbot;

import com.chatservice.chatbot_service.exceptions.OpenAIGenericException;
import com.chatservice.chatbot_service.exceptions.OpenAITimeoutException;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

public class OpenaiConnector implements ModelConnector, ChatbotConnector {
	private final String key;
	private final String responseModel;
	private final String responseEndpoint;
	private final String threadEndpoint;
	private final String assistantId;
	private final long runMaxSeconds = 15L;
	private final long runIntervalSeconds = 1L;

	// Bulldog personality system instruction
	private final String bulldogPersona = 
		"You are a bulldog: loyal, gruff but warm-hearted, protective, and straightforward. " +
		"When you answer, sound like a bulldog — short, confident, sometimes with canine metaphors. " +
		"Stay in character for all responses.";

	public OpenaiConnector() {
		this.key = System.getenv("openai.key");
		this.responseModel = System.getenv("openai.responseModel");
		this.responseEndpoint = System.getenv("openai.responseEndpoint");
		this.threadEndpoint = System.getenv("openai.threadEndpoint");
		this.assistantId = System.getenv("openai.assistantId");
	}
	
	public String Prompt(String prompt) {
		VerifyResponseConfig();
		HttpResponse<String> response = null;
		try {
			HttpClient client = HttpClient.newHttpClient();

			String fullPromptJson = String.format(
				"{\"model\": \"%s\", \"messages\": [" +
					"{\"role\": \"system\", \"content\": \"%s\"}," +
					"{\"role\": \"user\", \"content\": \"%s\"}" +
				"]}", responseModel, bulldogPersona, escapeJson(prompt)
			);

			HttpRequest request = HttpRequest.newBuilder()
					.uri(URI.create(responseEndpoint))
					.header("Authorization", "Bearer " + key)
					.header("Content-Type", "application/json")
					.POST(HttpRequest.BodyPublishers.ofString(fullPromptJson))
					.build();

			response = client.send(request, HttpResponse.BodyHandlers.ofString());

			if(response.statusCode() >= 200 && response.statusCode() < 300){
				return ExtractValueFromJSONResponse("content", response.body());
			}else{
				throw new Exception("Failed to prompt OpenAI.");
			}
	    } catch (Exception e) {
			if(response == null){
				throw new OpenAIGenericException(e.getMessage());
			}else{
				throw new OpenAIGenericException(e.getMessage(), response.body());
			}
		}
	}

	@Override
	public String CreateThread() {
		VerifyThreadConfig();
		HttpResponse<String> response = null;
		try {
			HttpClient client = HttpClient.newHttpClient();

			HttpRequest request = HttpRequest.newBuilder()
					.uri(URI.create(threadEndpoint))
					.header("Authorization", "Bearer " + key)
					.header("Content-Type", "application/json")
					.header("OpenAI-Beta", "assistants=v2")
					.POST(HttpRequest.BodyPublishers.ofString(""))
					.build();

			response = client.send(request, HttpResponse.BodyHandlers.ofString());

			if(response.statusCode() >= 200 && response.statusCode() < 300){
				return ExtractValueFromJSONResponse("id",response.body());
			}else{
				throw new Exception("Failed to create OpenAI thread.");
			}
		} catch (Exception e) {
			if(response == null){
				throw new OpenAIGenericException(e.getMessage());
			}else{
				throw new OpenAIGenericException(e.getMessage(), response.body());
			}
		}
	}

	private String RunAssistantOnThread(String assistId, String threadId){
		VerifyThreadConfig();
		HttpResponse<String> response = null;
		try {
			HttpClient client = HttpClient.newHttpClient();

			HttpRequest request = HttpRequest.newBuilder()
					.uri(URI.create(threadEndpoint + "/" + threadId + "/runs"))
					.header("Authorization", "Bearer " + key)
					.header("Content-Type", "application/json")
					.header("OpenAI-Beta", "assistants=v2")
					.POST(HttpRequest.BodyPublishers.ofString("{\"assistant_id\": \"" + assistId + "\"}"))
					.build();

			response = client.send(request, HttpResponse.BodyHandlers.ofString());

			if(response.statusCode() >= 200 && response.statusCode() < 300){
				return response.body();
			}else{
				throw new Exception("Failed to run assistant on thread.");
			}
		} catch (Exception e) {
			if(response == null){
				throw new OpenAIGenericException(e.getMessage());
			}else{
				throw new OpenAIGenericException(e.getMessage(), response.body());
			}
		}
	}

	@Override
	public String PromptThread(String message, String threadId) {
		VerifyThreadConfig();

		// Prepend bulldog persona to threaded messages
		String bulldogMessage = bulldogPersona + " " + message;
		MessageThread(bulldogMessage, threadId);

		String runId = ExtractValueFromJSONResponse("id", RunAssistantOnThread(assistantId, threadId));
		boolean finishedInTime = ConfirmRunCompletion(threadId, runId, 1L, 10f);

		if(finishedInTime){
			return GetThreadResponse(threadId);
		}else{
			throw new OpenAITimeoutException("Assistant run timed out.", "Time: " + runMaxSeconds + ", Interval: " + runIntervalSeconds);
		}
	}

	private void MessageThread(String message, String threadId){
		VerifyThreadConfig();
		HttpResponse<String> response = null;
		try {
			HttpClient client = HttpClient.newHttpClient();

			HttpRequest request = HttpRequest.newBuilder()
					.uri(URI.create(threadEndpoint + "/" + threadId + "/messages"))
					.header("Authorization", "Bearer " + key)
					.header("Content-Type", "application/json")
					.header("OpenAI-Beta", "assistants=v2")
					.POST(HttpRequest.BodyPublishers.ofString("{\"role\": \"user\", \"content\": \"" + escapeJson(message) + "\"}"))
					.build();

			response = client.send(request, HttpResponse.BodyHandlers.ofString());

			if(response.statusCode() < 200 || response.statusCode() >= 300){
				throw new Exception("Failed to message OpenAI thread.");
			}
		} catch (Exception e) {
			if(response == null){
				throw new OpenAIGenericException(e.getMessage());
			}else{
				throw new OpenAIGenericException(e.getMessage(), response.body());
			}
		}
	}

	public String AddContextToThread(String message, String threadId){
		VerifyThreadConfig();
		HttpResponse<String> response = null;
		try {
			HttpClient client = HttpClient.newHttpClient();

			HttpRequest request = HttpRequest.newBuilder()
					.uri(URI.create(threadEndpoint + "/" + threadId + "/messages"))
					.header("Authorization", "Bearer " + key)
					.header("Content-Type", "application/json")
					.header("OpenAI-Beta", "assistants=v2")
					.POST(HttpRequest.BodyPublishers.ofString("{\"role\": \"assistant\", \"content\": \"" + escapeJson(message) + "\"}"))
					.build();

			response = client.send(request, HttpResponse.BodyHandlers.ofString());

			if(response.statusCode() >= 200 && response.statusCode() < 300){
				return "Context added successfully.";
			}else{
				throw new Exception("Failed to add context to OpenAI thread.");
			}
		} catch (Exception e) {
			if(response == null){
				throw new OpenAIGenericException(e.getMessage());
			}else{
				throw new OpenAIGenericException(e.getMessage(), response.body());
			}
		}
	}

	@Override
	public String GetThreadResponse(String threadId) {
		VerifyThreadConfig();
		HttpResponse<String> response = null;
		try {
			HttpClient client = HttpClient.newHttpClient();

			HttpRequest request = HttpRequest.newBuilder()
					.uri(URI.create(threadEndpoint + "/" + threadId + "/messages"))
					.header("Authorization", "Bearer " + key)
					.header("Content-Type", "application/json")
					.header("OpenAI-Beta", "assistants=v2")
					.build();

			response = client.send(request, HttpResponse.BodyHandlers.ofString());

			if(response.statusCode() >= 200 && response.statusCode() < 300){
				String JSONObject = ExtractJSONObjectFromList(1,1,response.body());
				if(JSONObject != null){
					String value = ExtractValueFromJSONResponse("value", JSONObject);
					return CleanStringFormat(value);
				}else{
					throw new Exception("Failed to extract message from thread.");
				}
			}else{
				throw new Exception("Failed to get thread response");
			}
		} catch (Exception e) {
			if(response == null){
				throw new OpenAIGenericException(e.getMessage());
			}else{
				throw new OpenAIGenericException(e.getMessage(), response.body());
			}
		}
	}

	public String GetRunStatus(String threadId, String runId) {
		VerifyThreadConfig();
		HttpResponse<String> response = null;
		try {
			HttpClient client = HttpClient.newHttpClient();

			HttpRequest request = HttpRequest.newBuilder()
					.uri(URI.create(threadEndpoint + "/" + threadId + "/runs/" + runId))
					.header("Authorization", "Bearer " + key)
					.header("OpenAI-Beta", "assistants=v2")
					.build();

			response = client.send(request, HttpResponse.BodyHandlers.ofString());

			if(response.statusCode() >= 200 && response.statusCode() < 300){
				return ExtractValueFromJSONResponse("status", response.body());
			}else{
				throw new Exception("Failed to get run.");
			}
		} catch (Exception e) {
			if(response == null){
				throw new OpenAIGenericException(e.getMessage());
			}else{
				throw new OpenAIGenericException(e.getMessage(), response.body());
			}
		}
	}

	private void VerifyResponseConfig(){
		if(key == null || key.isEmpty()){
			throw new OpenAIGenericException("OpenAI key not configured on server.", "An OpenAI access key must be configured in the server's environment variables to use this endpoint.");
		}
		if(responseModel == null || responseModel.isEmpty()){
			throw new OpenAIGenericException("OpenAI response model not configured on server.", "An OpenAI response model must be configured in the server's environment variables to use this endpoint.");
		}
		if(responseEndpoint == null || responseEndpoint.isEmpty()){
			throw new OpenAIGenericException("OpenAI response endpoint not configured on server.", "The OpenAI response API endpoint must be configured in the server's environment variables to use this endpoint.");
		}
	}

	private void VerifyThreadConfig(){
		if(key == null || key.isEmpty()){
			throw new OpenAIGenericException("OpenAI key not configured on server.", "An OpenAI access key must be configured in the server's environment variables to use this endpoint.");
		}
		if(threadEndpoint == null || threadEndpoint.isEmpty()){
			throw new OpenAIGenericException("OpenAI thread endpoint not configured on server.", "The OpenAI API thread endpoint must be configured in the server's environment variables to use this endpoint.");
		}
	}
	
	private String ExtractValueFromJSONResponse(String property, String response) {
       int start = response.indexOf(property) + property.length() + 4;
	   Integer end = null;
	   boolean escape = false;
	   for(int i = start; i < response.length(); i++){
		   char currentChar = response.charAt(i);
		   if(currentChar == '"' && !escape){
			   end = i;
			   break;
		   }else{
			   escape = (currentChar == '\\');
		   }
	   }
	   if(end != null){
		   return response.substring(start, end);
	   }else {
		   return "Could not parse " + property + ".";
	   }
   }

   private String ExtractJSONObjectFromList(int itemNumber, int itemDepth, String json){
		if(itemNumber < 1){
			System.out.println("Extract JSON object failure: item number may not be lower than 1.");
			return null;
		}
	    if(itemDepth < 0){
		   System.out.println("Extract JSON object failure: item depth may not be lower than 0.");
		   return null;
	    }
		int ignoredOpeningBraces = 0;
		int unclosedBraces = 0;
		int objectsFound = 0;
		Integer objectStart = null;
		Integer objectEnd = null;
		for(int i = 0; i < json.length(); i++){
			char currentChar = json.charAt(i);
			if(currentChar == '{'){
				if(ignoredOpeningBraces < itemDepth){
					ignoredOpeningBraces++;
				}
				else{
					unclosedBraces++;
					if(unclosedBraces == 1){
						objectsFound++;
						if(objectsFound == itemNumber){
							objectStart = i;
						}
					}
				}
			}
			else if(currentChar == '}'){
				if(unclosedBraces < 1){
					System.out.println("No JSON object found at the desired position.");
					return null;
				}
				unclosedBraces--;
				if(objectStart != null && unclosedBraces == 0){
					objectEnd = i;
					break;
				}
			}
		}
		if(objectStart == null || objectEnd == null){
			System.out.println("No JSON object found at the desired position.");
			return null;
		}
		return json.substring(objectStart, objectEnd + 1);
   }

   private boolean ConfirmRunCompletion(String threadId, String runId, long interval, float maxTime){
		long timeWaited = 0L;
		for(; timeWaited <= maxTime; timeWaited += interval){
            try {
				if(GetRunStatus(threadId, runId).equals("completed")){
					return true;
				}
                TimeUnit.SECONDS.sleep(interval);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
		return false;
   }

   private String CleanStringFormat(String input){
	   HashMap<String,String> replacements = new HashMap<>();
	   replacements.put("\\n", "\n");
	   replacements.put("\\\"", "\"");
	   String output = "" + input;
	   for(String textToReplace : replacements.keySet()){
		   output = output.replace(textToReplace, replacements.get(textToReplace));
	   }
	   return output;
   }

   private String escapeJson(String text) {
	   return text.replace("\"", "\\\"");
   }
}
