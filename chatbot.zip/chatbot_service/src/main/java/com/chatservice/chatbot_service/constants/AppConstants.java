package com.chatservice.chatbot_service.constants;

public class AppConstants {
    public static final String chatbotHello = "You have successfully connected to the chatbot service, but you must format your request as a JSON POST, storing your message as 'prompt'.";
}
