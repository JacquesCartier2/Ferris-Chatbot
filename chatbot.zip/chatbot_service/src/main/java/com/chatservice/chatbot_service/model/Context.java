package com.chatservice.chatbot_service.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class Context {
    String date;
    String time;
}
